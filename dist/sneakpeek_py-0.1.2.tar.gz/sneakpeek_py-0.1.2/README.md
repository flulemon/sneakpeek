# sneakpeak

Tool box for creating scrapers, so that you only focus on scraping logic